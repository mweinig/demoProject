// InputCustomerKeyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IBSU_FunctionTester.h"
#include "InputCustomerKeyDlg.h"
#include "IBSU_FunctionTesterDlg.h"


// CInputCustomerKeyDlg dialog

IMPLEMENT_DYNAMIC(CInputCustomerKeyDlg, CDialog)

CInputCustomerKeyDlg::CInputCustomerKeyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInputCustomerKeyDlg::IDD, pParent)
{
    m_pParent = (CIBSU_FunctionTesterDlg*) pParent;
}

CInputCustomerKeyDlg::~CInputCustomerKeyDlg()
{
}

void CInputCustomerKeyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CInputCustomerKeyDlg, CDialog)
    ON_BN_CLICKED(IDC_BUTTON_APPLY, &CInputCustomerKeyDlg::OnBnClickedButtonApply)
    ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CInputCustomerKeyDlg::OnBnClickedButtonCancel)
    ON_BN_CLICKED(IDC_CHECK_SHOW_CHARACTER, &CInputCustomerKeyDlg::OnBnClickedCheckShowCharacter)
END_MESSAGE_MAP()


// CInputCustomerKeyDlg message handlers

void CInputCustomerKeyDlg::OnBnClickedButtonApply()
{
    GetDlgItemText(IDC_EDIT_CUSTOMER_KEY, m_pParent->m_CustomerKey);
    CDialog::OnOK();
}

void CInputCustomerKeyDlg::OnBnClickedButtonCancel()
{
    CDialog::OnCancel();
}

void CInputCustomerKeyDlg::OnBnClickedCheckShowCharacter()
{

}

BOOL CInputCustomerKeyDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    SetDlgItemText(IDC_EDIT_CUSTOMER_KEY, m_pParent->m_CustomerKey);

    return TRUE;
}

BOOL CInputCustomerKeyDlg::PreTranslateMessage(MSG* pMsg)
{
    if (pMsg->message == WM_KEYDOWN)
    {
        if (pMsg->wParam == VK_RETURN)
        {
            OnBnClickedButtonApply();
            return TRUE;
        }
        else if(pMsg->wParam == VK_ESCAPE)
        {
            OnBnClickedButtonCancel();
            return TRUE;
        }
    }

    return CDialog::PreTranslateMessage(pMsg);
}
