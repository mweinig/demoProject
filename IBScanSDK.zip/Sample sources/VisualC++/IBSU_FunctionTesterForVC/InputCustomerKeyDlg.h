#pragma once

class CIBSU_FunctionTesterDlg;
// CInputCustomerKeyDlg dialog

class CInputCustomerKeyDlg : public CDialog
{
	DECLARE_DYNAMIC(CInputCustomerKeyDlg)

public:
	CInputCustomerKeyDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CInputCustomerKeyDlg();

    CIBSU_FunctionTesterDlg *m_pParent;
// Dialog Data
	enum { IDD = IDD_DIALOG_INPUT_CUSTOMER_KEY };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedButtonApply();
    afx_msg void OnBnClickedButtonCancel();
    afx_msg void OnBnClickedCheckShowCharacter();
    virtual BOOL OnInitDialog();
    virtual BOOL PreTranslateMessage(MSG* pMsg);
};
