// InputCustomerKeyDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "IBScanUltimate_SampleForVC.h"
#include "InputCustomerKeyDlg.h"
#include "IBScanUltimate_SampleForVCDlg.h"


// CInputCustomerKeyDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CInputCustomerKeyDlg, CDialog)

CInputCustomerKeyDlg::CInputCustomerKeyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CInputCustomerKeyDlg::IDD, pParent)
{
    m_pParent = (CIBScanUltimate_SampleForVCDlg*) pParent;
}

CInputCustomerKeyDlg::~CInputCustomerKeyDlg()
{
}

void CInputCustomerKeyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CInputCustomerKeyDlg, CDialog)
    ON_BN_CLICKED(IDC_BUTTON_APPLY, &CInputCustomerKeyDlg::OnBnClickedButtonApply)
    ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CInputCustomerKeyDlg::OnBnClickedButtonCancel)
    ON_BN_CLICKED(IDC_CHECK_SHOW_CHARACTER, &CInputCustomerKeyDlg::OnBnClickedCheckShowCharacter)
END_MESSAGE_MAP()


// CInputCustomerKeyDlg �޽��� ó�����Դϴ�.

void CInputCustomerKeyDlg::OnBnClickedButtonApply()
{
    GetDlgItemText(IDC_EDIT_CUSTOMER_KEY, m_pParent->m_CustomerKey);
    CDialog::OnOK();
}

void CInputCustomerKeyDlg::OnBnClickedButtonCancel()
{
    CDialog::OnCancel();
}

void CInputCustomerKeyDlg::OnBnClickedCheckShowCharacter()
{
 //   CEditb   *pEdit = (CEdit*) GetDlgItem(IDC_EDIT_CUSTOMER_KEY);

	//const static TCHAR cPasswordChar = pEdit->GetPasswordChar();

 //   if( IsDlgButtonChecked(IDC_CHECK_SHOW_CHARACTER) == TRUE )
	//{
	//	pEdit->SetPasswordChar(NULL); // �Է� ���� ǥ��

	//}
	//else
	//{
	//	pEdit->SetPasswordChar(cPasswordChar); // �Է� ���� ����
	//}

	//pEdit->RedrawWindow(); // CEdit ��Ʈ�� ����
}

BOOL CInputCustomerKeyDlg::OnInitDialog()
{
    CDialog::OnInitDialog();

    SetDlgItemText(IDC_EDIT_CUSTOMER_KEY, m_pParent->m_CustomerKey);

    return TRUE;  // return TRUE unless you set the focus to a control
    // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}

BOOL CInputCustomerKeyDlg::PreTranslateMessage(MSG* pMsg)
{
    if (pMsg->message == WM_KEYDOWN)
    {
        if (pMsg->wParam == VK_RETURN)
        {
            OnBnClickedButtonApply();
            return TRUE;
        }
        else if(pMsg->wParam == VK_ESCAPE)
        {
            OnBnClickedButtonCancel();
            return TRUE;
        }
    }

    return CDialog::PreTranslateMessage(pMsg);
}
