//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IBScanUltimate_SampleForVC.rc
//
#define IDD_IBSCANULTIMATE_SAMPLEFORVC_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_SCANNER              133
#define IDB_BITMAP_IB_LOGO              134
#define IDB_BITMAP_BANNER               137
#define IDD_DIALOG_INPUT_CUSTOMER_KEY   138
#define IDB_BITMAP_STATUS_LOCKED        141
#define IDB_BITMAP_DEVICES              145
#define IDB_BITMAP_FINGERPRINT_CAPTURE  146
#define IDB_BITMAP1                     147
#define IDB_BITMAP_DEVICE_STATUS        147
#define IDC_COMBO_DEVICES               1000
#define IDC_TXT_STATUS                  1001
#define IDC_COMBO_CAPTURE_SEQ           1002
#define IDC_BTN_CAPTURE_START           1003
#define IDC_BTN_CAPTURE_STOP            1004
#define IDC_CHECK_AUTO_CONTRAST         1005
#define IDC_STATIC_CONTRAST             1006
#define IDC_CHECK_AUTO_CAPTURE          1007
#define IDC_CHECK_SAVE_IMAGES           1009
#define IDC_CHECK_CLEAR_PLATEN          1011
#define IDC_BTN_IMAGE_FOLDER            1012
#define IDC_FRAME_IMAGE                 1013
#define IDC_DISPLAY_AREA1               1014
#define IDC_CHECK_SAVE_IMAGES2          1014
#define IDC_CHECK_ASYNC_OPEN_DEVICE     1014
#define IDC_DISPLAY_AREA2               1015
#define IDC_CHECK_ACTUALWINDOW          1015
#define IDC_DISPLAY_AREA3               1016
#define IDC_CHECK_ASYNC_OPEN_DEVICE2    1016
#define IDC_CHECK_OPEN_DEVICE_EX        1016
#define IDC_DISPLAY_AREA4               1017
#define IDC_CHECK_CLEAR_PLATEN2         1017
#define IDC_CHECK_SUPER_DRY_MODE        1017
#define IDC_DISPLAY_TOUCH_BAR           1018
#define IDC_CHECK_ACTUALWINDOW2         1018
#define IDC_CHECK_ENABLE_ENCRYPTION     1018
#define IDC_DISPLAY_TOUCH_BAR2          1019
#define IDC_DISPLAY_PRODUCTNAME         1019
#define IDC_PIC_SCANNER                 1020
#define IDC_EDIT_CONTRAST               1022
#define IDC_PIC_IB_LOGO                 1023
#define IDC_STATIC_LOGO_1               1024
#define IDC_STATIC_COPYRIGHT            1024
#define IDC_STATIC_DLL_VER              1025
#define IDC_TXT_STATUS2                 1026
#define IDC_STATIC_QUALITY_1            1026
#define IDC_STATIC_QUALITY_2            1027
#define IDC_STATIC_QUALITY_3            1028
#define IDC_STATIC_QUALITY_4            1029
#define IDC_CHECK_IGNORE_FINGER_COUNT   1030
#define IDC_BUTTON1                     1031
#define IDC_BUTTON_APPLY                1031
#define IDC_BUTTON_CANCEL               1033
#define IDC_CHECK1                      1034
#define IDC_CHECK_NFIQ                  1034
#define IDC_CHECK_SHOW_CHARACTER        1034
#define IDC_SLIDER_CONTRAST             1035
#define IDC_EDIT_NFIQ                   1036
#define IDC_CHECK_NFIQ2                 1037
#define IDC_CHECK_DRAW_SEGMENT_IMAGE    1037
#define IDC_CHECK_INVALID_AREA          1038
#define IDC_CHECK_SMEAR                 1039
#define IDC_COMBO1                      1040
#define IDC_COMBO_SMEAR_LEVEL           1040
#define IDC_EDIT_CUSTOMER_KEY           1041
#define IDC_EDIT_SPOOF_RESULT           1041
#define IDC_CHECK_SPOOF                 1042
#define IDC_COMBO_SPOOF_LEVEL           1043
#define IDC_EDIT_CUSTOMER_STRING        1044
#define IDC_STATIC_DEVICE_LOCK_STATE    1046
#define IDC_STATIC_DEVICE_LOCK_STATE1   1046
#define IDC_CHECK2                      1048
#define IDC_CHECK_CUSTOMER_KEY          1048
#define IDC_STATIC_DEVICELIST           1050
#define IDC_STATIC_CAPTURE              1051
#define IDC_STATIC_3                    1052
#define IDC_STATIC_2                    1053
#define IDC_STATIC_5                    1054
#define IDC_STATIC_1                    1054
#define IDC_STATIC_GROUP_BORDER         1054
#define IDC_STATIC_GROUP_BORDER_1       1054
#define IDC_STATIC_CAPTURE2             1055
#define IDC_STATIC_DEVICE_STATUS        1055
#define IDC_STATIC_GROUP_BORDER_2       1055
#define IDC_STATIC_DEVICE_STATUS2       1056
#define IDC_STATIC_STATUS_LOCKED        1056
#define IDC_STATIC_GROUP_BORDER_3       1057

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
