#pragma once

class CIBScanUltimate_SampleForVCDlg;
// CInputCustomerKeyDlg ��ȭ �����Դϴ�.

class CInputCustomerKeyDlg : public CDialog
{
	DECLARE_DYNAMIC(CInputCustomerKeyDlg)

public:
	CInputCustomerKeyDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CInputCustomerKeyDlg();

    CIBScanUltimate_SampleForVCDlg *m_pParent;
// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_DIALOG_INPUT_CUSTOMER_KEY };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedButtonApply();
    afx_msg void OnBnClickedButtonCancel();
    afx_msg void OnBnClickedCheckShowCharacter();
    virtual BOOL OnInitDialog();
    virtual BOOL PreTranslateMessage(MSG* pMsg);
};
